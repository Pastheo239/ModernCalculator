﻿using Microsoft.Maui.Controls;
using Microsoft.Maui.Graphics;

namespace CalculadoraRelease;

public class CircleButton : Button
{
    public CircleButton()
    {
        WidthRequest = 80;
        HeightRequest = 80;
        BackgroundColor = Color.FromArgb("#505050");
        TextColor = Colors.White;
        FontSize = 24;
        CornerRadius = 40;
        FontAttributes = FontAttributes.Bold;
        Margin = new Thickness(4);
    }
}