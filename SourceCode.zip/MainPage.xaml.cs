﻿using Microsoft.Maui.Controls;
#if WINDOWS
using Microsoft.UI;
using Microsoft.UI.Windowing;
using Windows.Graphics;
#endif
using System;

namespace CalculadoraRelease;

public partial class MainPage : ContentPage
{
    string currentEntry = "0";
    double firstNumber;
    string operation;
    bool isNewEntry = false;

    public MainPage()
    {
        InitializeComponent();

    #if WINDOWS
            Microsoft.Maui.Handlers.WindowHandler.Mapper.AppendToMapping(nameof(IWindow), (handler, view) =>
            {
                var mauiWindow = handler.VirtualView;
                var nativeWindow = handler.PlatformView;
                var hwnd = WinRT.Interop.WindowNative.GetWindowHandle(nativeWindow);
                var id = Microsoft.UI.Win32Interop.GetWindowIdFromWindow(hwnd);
                var appWindow = Microsoft.UI.Windowing.AppWindow.GetFromWindowId(id);

                appWindow.MoveAndResize(new Windows.Graphics.RectInt32
                {
                    X = (DisplayArea.Primary.WorkArea.Width - 320) / 2,
                    Y = (DisplayArea.Primary.WorkArea.Height - 480) / 2,
                    Width = 400,
                    Height = 700
                });
            });
    #endif
    }

    void OnDigitClicked(object sender, EventArgs e)
    {
        string digit = (sender as Button)?.Text;

        if (currentEntry == "0" || isNewEntry)
        {
            currentEntry = digit;
            isNewEntry = false;
        }
        else
        {
            currentEntry += digit;
        }

        Display.Text = currentEntry;
    }

    void OnDecimal(object sender, EventArgs e)
    {
        if (!currentEntry.Contains("."))
        {
            currentEntry += ".";
            Display.Text = currentEntry;
        }
    }

    void OnClear(object sender, EventArgs e)
    {
        currentEntry = "0";
        firstNumber = 0;
        operation = null;
        isNewEntry = false;
        Display.Text = "0";
    }

    void OnToggleSign(object sender, EventArgs e)
    {
        if (double.TryParse(currentEntry, out double num))
        {
            num = -num;
            currentEntry = num.ToString();
            Display.Text = currentEntry;
        }
    }

    void OnPercent(object sender, EventArgs e)
    {
        if (double.TryParse(currentEntry, out double num))
        {
            num /= 100;
            currentEntry = num.ToString();
            Display.Text = currentEntry;
        }
    }

    void OnOperatorClicked(object sender, EventArgs e)
    {
        if (double.TryParse(currentEntry, out double num))
        {
            firstNumber = num;
            operation = (sender as Button)?.Text;
            isNewEntry = true;
        }
    }

    void OnCalculate(object sender, EventArgs e)
    {
        if (double.TryParse(currentEntry, out double secondNumber))
        {
            double result = 0;

            switch (operation)
            {
                case "+":
                    result = firstNumber + secondNumber;
                    break;
                case "−":
                    result = firstNumber - secondNumber;
                    break;
                case "×":
                    result = firstNumber * secondNumber;
                    break;
                case "÷":
                    result = secondNumber != 0 ? firstNumber / secondNumber : 0;
                    break;
            }

            currentEntry = result.ToString();
            Display.Text = currentEntry;
            isNewEntry = true;
        }
    }
}